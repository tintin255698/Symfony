<?php

namespace App\Controller;


use App\Entity\Ad;
use App\Entity\Image;
use App\Form\AdType;
use App\Repository\AdRepository;
use Doctrine\Persistence\ObjectManager;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;




class AdController extends AbstractController
{
    /**
     * @Route("/ads", name="ads_index")
     */
    public function index()
    {
        $repo = $this->getDoctrine()->getRepository(Ad::class);
        $ads = $repo->findAll();

        return $this->render('ad/index.html.twig', ['ads' => $ads]);

    }

    /**
     * Permet de creer une annonce
     *
     * @Route("/ads/new", name="ads_create")
     *
     */
    public function create(Request $request, ObjectManager $manager){
        $ad = new ad();

        $image=new Image();
        $image2 = new Image();

        $image->setUrl('http://placeholder.it/400*200');
        $image->setCaption('Titre1');

        $image2->setUrl('http://placeholder.it/400*200');
        $image2->setCaption('Titre2');


        $ad->addImage($image);
        $ad->addImage($image2);

        $form = $this->createForm(AdType::class, $ad);

        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){

            $manager = $this->getDoctrine()->getManager();
            $manager->persist($ad);
            $manager->flush();


        return $this->redirectToRoute('ads_show', ['slug' =>$ad->getSlug()]);

        }

        return $this->render('ad/new.html.twig', [
            'form' => $form->createView()
        ]);
    }


    /**
     * Permet d'afficher une seule reponse
     *
     * @Route("/ads/{slug}", name="ads_show")
     *
     *
     */
    public function show($slug, AdRepository $repo){
        $ad = $repo->findOneBySlug($slug);
        return $this->render('ad/show.html.twig', ['ad' => $ad]);

    }

}
