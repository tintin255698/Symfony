<?php

namespace App\DataFixtures;

use App\Entity\Ad;
use App\Entity\Image;
use App\Entity\User;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\Persistence\ObjectManager;
use Faker\Factory;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;

class AppFixtures extends Fixture
{
    private $encoder;

    public function __construct(UserPasswordEncoderInterface $encoder)
    {
        $this->encoder = $encoder;
    }


    public function load(ObjectManager $manager)
    {
        $faker = Factory::create('FR-fr');

        //Nous gerons les utilisateurs

        $users =[];
        $genres =['male', 'female'];

        for($i=1; $i<=10; $i++){
            $user = new User();

        $genre=$faker->randomElement($genres);

        $picture = 'https://randomuser.me/api/portraits/';
        $pictureId = $faker->numberBetween(1,99).'.jpg';

        $picture = $picture. ($genre == 'male' ? 'men/' : 'women/').$pictureId;

        $hash = $this->encoder->encodePassword($user, 'password');

            $user->setFirstName($faker->firstName($genre));
            $user->setLastName($faker->lastName);
            $user->setEmail($faker->email);
            $user->setIntroduction($faker->sentence());
            $user->setDescription('<p>'.join('</p><p>',$faker->paragraphs(3)).'</p>');
            $user->setHash($hash);
            $user->setPicture($picture);

            $manager->persist($user);
            $users[] = $user;

        }
        //Nous gerons les annonces

       for($i =1; $i<=30; $i++) {
           $ad = new ad();

           $title = $faker->sentence();
           $coverImage=$faker->imageURL(1000,50);
           $introduction = $faker->paragraph(2);
           $content = '<p>'.join('</p><p>',$faker->paragraphs(5)).'</p>';

           $user = $users[mt_rand(0,count($users) - 1)];



           $ad->setTitle($title);
           $ad->setCoverImage($coverImage);
           $ad->setIntroduction($introduction);
           $ad->setContent($content);
           $ad->setPrice(mt_rand(40,200));
           $ad->setRooms(mt_rand(1,5));
           $ad->setAuthor($user);

       for($j=1; $j <= mt_rand(2, 5); $j++) {
           $image = new Image();

           $image->setUrl($faker->imageUrl());
           $image->setCaption($faker->sentence());
           $image->setRelation($ad);

           $manager->persist($image);
       }

           $manager->persist($ad);
       }

           $manager->flush();
    }
}
