<?php

namespace App\Form;

use Symfony\Component\Form\AbstractType;

class ApplicationType extends \Symfony\Component\Form\AbstractType {

    /**
     * Permet d'avoir la configuration de base d'un champ !
     * @param $label
     * @param $placeholder
     * @return array
     */

    protected function getConfiguration($label, $placeholder){
        return[
            'label' => $label,
            'attr' => ['placeholder' => $placeholder]
        ];

    }



}

